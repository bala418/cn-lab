import java.io.*;
import java.net.*;
public class EchoServer {
    public static void main(String[] args) throws IOException{
        ServerSocket ss = new ServerSocket(8080);
        Socket s = ss.accept();
        System.out.println("Connection established.....");
        InputStreamReader socIn = new InputStreamReader(s.getInputStream());
        BufferedReader in = new BufferedReader(socIn);
        String x;
        while (true) {
            x = in.readLine();
            System.out.println("Client : " + x);
            if (x.equalsIgnoreCase("terminate")){
                System.out.println("Connection terminated!!!");
                break;
            }
        }
        ss.close();
    }
}