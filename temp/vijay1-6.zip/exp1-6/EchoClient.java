import java.io.*;
import java.net.*;
public class EchoClient{
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 8080);
        System.out.println("Connection established...");
        PrintWriter pr = new PrintWriter(s.getOutputStream(), true);
        InputStreamReader sysIn = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(sysIn);
        String y;
        while (true) {
            System.out.print("Enter message:");
            y = br.readLine();
            if (y.equalsIgnoreCase("terminate")) {
                System.out.println("Connection terminated!!!!");
                pr.println("terminate");
                break;
            } else
            pr.println(y);
        }
        s.close();
    }
}
