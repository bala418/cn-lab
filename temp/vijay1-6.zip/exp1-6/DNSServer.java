import java.util.*;
import java.net.*;

public class DNSServer {
    public static void main(String args[]) {
        try {
            DatagramSocket server = new DatagramSocket(1309);
            while (true) {
                byte[] sendbyte = new byte[1024];
                byte[] receivebyte = new byte[1024];
                DatagramPacket receiver = new DatagramPacket(receivebyte, receivebyte.length);
                server.receive(receiver);
                String str = new String(receiver.getData());
                String s = str.trim();
                InetAddress addr = receiver.getAddress();
                int port = receiver.getPort();
                String ip[] = {"14.139.161.7","208.113.187.177","14.139.161.121","172.217.13.78"};
                String name[] = {"www.annauniv.edu","www.mitindia.edu","www.aukdc.edu.in","www.google.com"};
                for (int i = 0; i < ip.length; i++) {
                    if (s.equals(ip[i])) {
                        sendbyte = name[i].getBytes();
                        DatagramPacket sender = new DatagramPacket(sendbyte, sendbyte.length, addr, port);
                        server.send(sender);
                        break;
                    } else if (s.equals(name[i])) {
                        sendbyte = ip[i].getBytes();
                        DatagramPacket sender = new DatagramPacket(sendbyte, sendbyte.length, addr, port);
                        server.send(sender);
                        break;
                    }
                }
                break;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
