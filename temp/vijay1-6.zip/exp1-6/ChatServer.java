import java.io.*;
import java.net.*;
public class ChatServer {
    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(8080);
        Socket s = ss.accept();
        System.out.println("Connection established...");
        InputStreamReader socIn = new InputStreamReader(s.getInputStream());
        BufferedReader in = new BufferedReader(socIn);
        InputStreamReader sysIn = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(sysIn);
        PrintWriter pr = new PrintWriter(s.getOutputStream(), true);
        String x, y;
        System.out.println("Type 'terminate' to Quit.....");
        while (true) {
            x = in.readLine();
            if (x.equalsIgnoreCase("terminate")) {
                System.out.println("Connection terminated!!!");
                break;
            }
            System.out.println("Client : " + x);
            System.out.print("Enter message:");
            y = br.readLine();
            if (y.equalsIgnoreCase("terminate")) {
                System.out.print("Connection terminated!!!");
                pr.println("terminate");
                break;
            } else
                pr.println(y);
        }
        ss.close();
    }
}
