import java.io.*;
import java.net.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;;
public class FTPClient {
    Socket soc;
    DataInputStream din;
    DataOutputStream dout;
    String fileName;
    public FTPClient() throws Exception{
        soc = new Socket("127.0.0.1",6060);
        System.out.println("Socket connected.....");
        din = new DataInputStream(soc.getInputStream());
        dout = new DataOutputStream(soc.getOutputStream());
    }
    public void getFile() throws Exception{
        String fileIn;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Filename : ");
        fileName = in.nextLine();
        dout.writeUTF(fileName);
        Path file = Paths.get(fileName);
        fileName = file.getFileName().toString();
        if(din.readUTF().equals("1")) {
            System.out.println("File is available....");
            File fileObj = new File(fileName);
            if(fileObj.exists()){
                System.out.println("File already existing in current folder....");
                System.out.print("Do you want to replace the file[Y/N] :");
                String ch = in.nextLine();
                if(ch.equalsIgnoreCase("n")){
                    System.out.print("Do you want to rename the received file[Y/N] :");
                    ch = in.nextLine();
                    if(ch.equalsIgnoreCase("n")){
                        System.out.println("File already exists. No further operations done!!!");
                        in.close();
                        return;
                    }
                    System.out.print("Enter new filename :");
                    fileName = in.nextLine();
                }
            }
            System.out.println("File transfer started.....");
            FileOutputStream fout = new FileOutputStream(fileName);
            while(!( fileIn = din.readUTF()).equals("-1")) fout.write(Integer.parseInt(fileIn));
            System.out.println("File transfer completed!!!!");
            fout.close();
        }
        else{
            System.out.println("File was not found....");
            System.out.println("Check file name or try again...");
        }
        in.close();
    }
    public static void main(String[] args) throws Exception{
        FTPClient instance = new FTPClient();
        instance.getFile();
        instance.soc.close();
        System.out.println("Socket closed.....");
    }
}