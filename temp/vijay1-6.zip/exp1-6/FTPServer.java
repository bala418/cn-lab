import java.net.*;
import java.io.*;
public class FTPServer {
    Socket ss;
    ServerSocket serverSoc;
    DataInputStream din;
    DataOutputStream dout;
    String fileName;
    File fileObject;
    public FTPServer() throws Exception{
        serverSoc = new ServerSocket(6060);
        System.out.println("Server started.......");
        ss = serverSoc.accept();
        System.out.println("Socket connected.....");        
        din = new DataInputStream(ss.getInputStream());
        dout = new DataOutputStream(ss.getOutputStream());
    }
    public void startTransfer() throws Exception{
        int readByte;
        FileInputStream fStream = new FileInputStream(fileName);
        System.out.println("File transfer started....");
        while((readByte = fStream.read()) != -1) dout.writeUTF(String.valueOf(readByte));
        dout.writeUTF("-1");
        System.out.println("File transfer completed successfully!!!");
        fStream.close(); 
    }
    public void sendFile() throws Exception{
        fileName = din.readUTF();
        System.out.println("File name: "+fileName);
        fileObject = new File(fileName);
        if(fileObject.exists()){
            dout.writeUTF("1");
            this.startTransfer();
        }
        else{
            System.out.println("File not found.....");
            dout.writeUTF("0");
        }
    }
    public static void main(String[] args) throws Exception{
        FTPServer instance = new FTPServer();
        instance.sendFile();
        instance.ss.close();
        instance.serverSoc.close();
        System.out.println("Socket disconnected and Server closed.....");
    }
}