import java.io.*;
import java.net.*;
public class ChatClient {
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 8080);
        System.out.println("Connection established.....");
        PrintWriter pr = new PrintWriter(s.getOutputStream(), true);
        InputStreamReader socIn = new InputStreamReader(s.getInputStream());
        BufferedReader in = new BufferedReader(socIn);
        InputStreamReader sysIn = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(sysIn);
        String x, y;
        System.out.println("Type 'terminate' to Quit.....");
        while (true) {
            System.out.print("Enter message:");
            y = br.readLine();
            pr.println(y);
            if (y.equalsIgnoreCase("terminate")) {
                System.out.println("Connection terminated!!!");
                break;
            }
            x = in.readLine();
            if (x.equalsIgnoreCase("terminate")){
                System.out.println("Connection terminated!!!");
                break;  
            } 
            System.out.println("Server : " + x);
        }
        s.close();
    }
}
